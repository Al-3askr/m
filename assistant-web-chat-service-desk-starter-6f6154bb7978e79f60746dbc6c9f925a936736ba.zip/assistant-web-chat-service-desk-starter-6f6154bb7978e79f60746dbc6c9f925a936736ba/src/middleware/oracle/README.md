# Oracle Cloud B2C Service Usage Example

The instructions and sample have been moved to [src/oracle/webChat](../../oracle/webChat).