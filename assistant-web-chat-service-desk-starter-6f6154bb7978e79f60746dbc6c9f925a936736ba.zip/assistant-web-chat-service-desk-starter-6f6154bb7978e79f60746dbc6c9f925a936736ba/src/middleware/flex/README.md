# Twilio Flex integration example

The instructions and sample have been moved to [src/flex/webChat](../../flex/webChat).