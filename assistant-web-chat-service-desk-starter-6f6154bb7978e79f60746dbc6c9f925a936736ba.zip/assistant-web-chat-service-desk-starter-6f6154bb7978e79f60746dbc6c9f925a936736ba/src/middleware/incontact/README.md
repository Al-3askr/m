# NICE inContact Integration Usage Example

The instructions and sample have been moved to [src/incontact/webChat](../../incontact/webChat).