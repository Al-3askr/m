# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## 1.0.0 (2020-09-23)

### Features

- Add Genesys PureCloud integration example ([1bb6d65](https://github.com/watson-developer-cloud/assistant-web-chat-service-desk-starter/commit/1bb6d6556df7429f2a8cd2203a5b641bb38b7751))

## 2.0.0 (2020-10-22)

### Features

- Add Twilio Flex integration example ([86fdd62](https://github.com/watson-developer-cloud/assistant-web-chat-service-desk-starter/commit/86fdd62faec0ddeb8da044f0592ebd12fbd3d860))
- BREAKING CHANGE: Make buildEntry getInstance environment variable driven

## 3.0.0 (2020-12-08)

### Features

- Add Nice inContact integration example ([5077624](https://github.com/watson-developer-cloud/assistant-web-chat-service-desk-starter/commit/50776246bd5c89d2685097832de41098046b68e3))
